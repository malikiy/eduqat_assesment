var Ok = 200
var Created = 201
var Unauthorized = 403
var InternalServerError = 500
var NotFound = 404
var badRequest= 400

export {
  Ok,
  Created,
  Unauthorized,
  InternalServerError,
  NotFound,
  badRequest,
}